/*
**  Copyright (C) 2012 Aldebaran Robotics
**  See COPYING for the license
*/

#pragma once

#ifndef ALICE_SERVICE_API_H_
#define ALICE_SERVICE_API_H_

#include <qi/macro.hpp>

#define ALICE_SERVICE_API QI_LIB_API(alice_service)

#endif /* !QICORE_API_H_ */
